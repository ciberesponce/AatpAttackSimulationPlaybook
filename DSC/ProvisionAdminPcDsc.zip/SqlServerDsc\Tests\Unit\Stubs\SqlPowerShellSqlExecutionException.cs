namespace Microsoft.SqlServer.Management.PowerShell
{
    public class SqlPowerShellSqlExecutionException : System.Exception
    {
        public SqlPowerShellSqlExecutionException()
        {
        }
    }
}
